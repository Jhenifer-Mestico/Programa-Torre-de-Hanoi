package hanoitda;

import java.util.Scanner;
public class HanoiTda {
    
    private static int n = 0, movimento = 0;
    public static void main(String[] args) {

       Scanner inputData = new Scanner(System.in);
       
       while (n < 1){ 
           try {
               System.out.println("Digite a quantidade de discos:");
               n = inputData.nextInt();
               
               if (n == 0 || n < 0)
                   throw new Exception();
               
           } catch (Exception hanoi){
               System.out.println("Por favor, digite apenas números maiores do que 0 (zero)");
               inputData.nextLine();
           }
        }
       
       int d[][] = new int [n + 1][3];
           d[0][0] = 1;
           d[0][1] = 2;
           d[0][2] = 3;
            for(int i = 1; (i <= n); i++){    
                d[i][0] = i;
            }
            HanoiTda.movimento(d);
            HanoiTda.hanoi(n, 1, 2, 3, d);
            
    } 
    
    private static void movimento(int d[][]) {
        System.out.println("\n Movimento = " + movimento);
            for(int i = 1; i <= n; i++){
        System.out.println("| "+d[i][0]+" | "+d[i][1]+" | "+d[i][2]+" |");  
    }
        System.out.println(" ------------");
        System.out.println("| A | B | C |");
        movimento++;
    }
		

    private static void hanoi(int n, int porigem, int ptrabalho, int pdestino, int d[][])
    {
        if (n > 0) {
			hanoi (n-1, porigem, pdestino, ptrabalho, d);
                        d[n][(pdestino-1)] = d[n][(porigem-1)];
                        d[n][(porigem-1)] = 0;
                        movimento(d);
                        hanoi(n - 1, ptrabalho, porigem, pdestino, d);
		}
	}
    }