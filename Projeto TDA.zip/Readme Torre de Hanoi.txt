Readme Torre de Hanoi

   Este projeto tem como enfoque movimentar uma quantidade n de discos sobre três hastes utilizando o JDK 8.
   Para a execução do projeto, serão necessárias as instalações dos seguintes programas gratuitos:
•	https://www.oracle.com/java/technologies/javase-downloads.html  - Necessário para execução do projeto em Java.
•	https://netbeans.org/downloads/8.2/rc/  - Necessário para o desenvolvimento do projeto (IDE).
   Todos esses programas, serão instalados na versão 8.2.
   É necessário fazer uma conta, caso não tenha, no Oracle, que é simples e rápido.
   Para iniciar o projeto, será necessário baixar os arquivos enviados compactados, descompactar e abrir no Netbeans já instalado, juntamente com o JDK.
   Assim que o projeto for aberto no Netbeans, pressione o botão f6, que irá rodar o projeto automaticamente, ou clique no botão acima de start (Executar projeto HanoiTda (f6)).
   O projeto pode ser usado para movimentar n quantidades de discos sobre três hastes simultaneamente, seguindo as regras do quebra cabeça da Torre de Hanoi: 
•	http://clubes.obmep.org.br/blog/torre-de-hanoi/ - Regras da Torre de Hanoi

   O jogo se inicia perguntando ao usuário quantos discos ele deseja. Se for colocado números menores que 0, sem ser inteiros ou negativos, é perguntado novamente quantos discos o usuário quer. Portanto, só é possível digitar números maiores que 0 e positivos.
   Assim, se inicia os movimentos pelas hastes A, B, e C, mostrando ao usuário, quantos movimentos a torre realizou.
